package com.example.mpcamera

import android.graphics.RectF
import android.view.View
import kotlin.math.hypot

/**
 * Controla a TV virtual com as mãos:
 *  - pinça em cima da TV      -> segura e arrasta
 *  - pinça com as DUAS mãos   -> aumenta / diminui
 *  - pinça num botão          -> clica
 *  - pinça na barra de tempo  -> pula pro ponto do vídeo (e arrasta)
 */
class TvController(
    private val container: View,
    private val progress: View,
    private val buttons: List<View>,
    private val onSeekFraction: (Float) -> Unit
) {
    private var cx = 0f
    private var cy = 0f
    private var scale = 0.6f
    private var vw = 0f
    private var vh = 0f

    private val prevPinch = BooleanArray(2)
    private var grabIdx = -1
    private var grabOffX = 0f
    private var grabOffY = 0f

    private var scaleMode = false
    private var startDist = 1f
    private var startScale = 1f
    private var scaleOffX = 0f
    private var scaleOffY = 0f

    private var seekIdx = -1

    fun reset(w: Float, h: Float) {
        vw = w
        vh = h
        cx = w / 2f
        cy = h * 0.4f
        scale = 0.6f
        apply()
    }

    private fun apply() {
        cx = cx.coerceIn(0f, vw)
        cy = cy.coerceIn(0f, vh)
        container.translationX = cx - container.width / 2f
        container.translationY = cy - container.height / 2f
        container.scaleX = scale
        container.scaleY = scale
    }

    private fun localX(px: Float) = (px - cx) / scale + container.width / 2f
    private fun localY(py: Float) = (py - cy) / scale + container.height / 2f

    private fun rectIn(v: View): RectF {
        var l = 0f
        var t = 0f
        var cur: View = v
        while (cur !== container) {
            l += cur.left
            t += cur.top
            cur = cur.parent as View
        }
        return RectF(l, t, l + v.width, t + v.height)
    }

    private fun insideTv(lx: Float, ly: Float, margin: Float = 10f) =
        lx >= -margin && ly >= -margin &&
            lx <= container.width + margin && ly <= container.height + margin

    fun process(pointers: Array<Pointer?>, w: Float, h: Float) {
        vw = w
        vh = h
        if (container.width == 0) return

        // 1) início de pinça
        for (i in 0..1) {
            val p = pointers[i]
            val pinching = p?.pinch == true
            if (pinching && !prevPinch[i]) onset(i, p!!, pointers)
            prevPinch[i] = pinching
        }

        // 2) escalar com duas mãos
        if (scaleMode) {
            val a = pointers[0]
            val b = pointers[1]
            if (a?.pinch == true && b?.pinch == true) {
                val d = hypot(a.x - b.x, a.y - b.y)
                scale = (startScale * d / startDist).coerceIn(0.3f, 2.2f)
                val mx = (a.x + b.x) / 2f
                val my = (a.y + b.y) / 2f
                val k = scale / startScale
                cx = mx + scaleOffX * k
                cy = my + scaleOffY * k
            } else {
                scaleMode = false
                grabIdx = -1
            }
        } else if (grabIdx >= 0) {
            // 3) arrastar com uma mão
            val p = pointers[grabIdx]
            if (p?.pinch == true) {
                cx = p.x + grabOffX
                cy = p.y + grabOffY
            } else grabIdx = -1
        }

        // 4) arrastar a barra de tempo
        if (seekIdx >= 0) {
            val p = pointers[seekIdx]
            if (p?.pinch == true) seekTo(localX(p.x)) else seekIdx = -1
        }

        apply()
    }

    private fun seekTo(lx: Float) {
        val r = rectIn(progress)
        onSeekFraction(((lx - r.left) / r.width()).coerceIn(0f, 1f))
    }

    private fun onset(i: Int, p: Pointer, pointers: Array<Pointer?>) {
        val j = 1 - i
        val other = pointers[j]

        // segunda mão pinçando enquanto a outra segura a TV -> modo escala
        if (other?.pinch == true && grabIdx == j && !scaleMode) {
            scaleMode = true
            startDist = hypot(p.x - other.x, p.y - other.y).coerceAtLeast(40f)
            startScale = scale
            val mx = (p.x + other.x) / 2f
            val my = (p.y + other.y) / 2f
            scaleOffX = cx - mx
            scaleOffY = cy - my
            return
        }

        val lx = localX(p.x)
        val ly = localY(p.y)
        if (!insideTv(lx, ly)) return

        for (b in buttons) {
            if (rectIn(b).contains(lx, ly)) {
                b.performClick()
                return
            }
        }

        val pr = rectIn(progress)
        if (lx >= pr.left && lx <= pr.right && ly >= pr.top - 10f && ly <= pr.bottom + 10f) {
            seekIdx = i
            seekTo(lx)
            return
        }

        grabIdx = i
        grabOffX = cx - p.x
        grabOffY = cy - p.y
    }
}
