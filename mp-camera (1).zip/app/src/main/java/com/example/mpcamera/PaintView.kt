package com.example.mpcamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Pintura 3D com a mão.
 *  - Pinça = pinta. A profundidade (Z) vem do tamanho da palma: mão perto = Z pequeno.
 *  - Os traços ficam guardados em 3D e são projetados com uma câmera orbital,
 *    então dá pra girar a cena (arrastando na tela ou no modo "Girar" com a pinça).
 */
class PaintView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private class Stroke(val color: Int, val width: Float) {
        var data = FloatArray(96)
        var n = 0
        fun add(x: Float, y: Float, z: Float) {
            if (n * 3 + 3 > data.size) data = data.copyOf(data.size * 2)
            data[n * 3] = x
            data[n * 3 + 1] = y
            data[n * 3 + 2] = z
            n++
        }
    }

    var color: Int = Color.parseColor("#FF3B30")
    var brushWidth = 12f
    var darkBackground = false
        set(v) {
            field = v
            invalidate()
        }
    var rotateMode = false
        set(v) {
            field = v
            endStroke()
            lastPx = Float.NaN
        }

    private val strokes = ArrayList<Stroke>()
    private var current: Stroke? = null
    private var totalPoints = 0

    private var yaw = 0f
    private var pitch = 0f

    private var smX = 0f
    private var smY = 0f
    private var smZ = 1f
    private var lastPx = Float.NaN
    private var lastPy = 0f
    private var tx = 0f
    private var ty = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // ---------- API ----------
    fun undo() {
        current = null
        if (strokes.isNotEmpty()) {
            val s = strokes.removeAt(strokes.size - 1)
            totalPoints -= s.n
        }
        invalidate()
    }

    fun clear() {
        current = null
        strokes.clear()
        totalPoints = 0
        invalidate()
    }

    fun resetView() {
        yaw = 0f
        pitch = 0f
        invalidate()
    }

    private fun endStroke() {
        current = null
    }

    // ---------- entrada pela mão ----------
    fun update(pointers: Array<Pointer?>) {
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vh == 0f) return

        val idx = when {
            pointers[0]?.pinch == true -> 0
            pointers[1]?.pinch == true -> 1
            else -> -1
        }
        if (idx < 0) {
            endStroke()
            lastPx = Float.NaN
            return
        }
        val p = pointers[idx]!!

        if (rotateMode) {
            if (!lastPx.isNaN()) {
                yaw -= (p.x - lastPx) * 0.006f
                pitch = (pitch + (p.y - lastPy) * 0.006f).coerceIn(-1.4f, 1.4f)
            }
            lastPx = p.x
            lastPy = p.y
            invalidate()
            return
        }

        val depth = (REF_PALM / max(p.palm, 0.02f)).coerceIn(0.35f, 3f)
        val cx = (p.x - vw / 2f) / vh * depth
        val cy = (p.y - vh / 2f) / vh * depth

        var s = current
        if (s == null) {
            smX = cx
            smY = cy
            smZ = depth
            s = Stroke(color, brushWidth)
            current = s
            strokes.add(s)
        } else {
            smX += (cx - smX) * 0.6f
            smY += (cy - smY) * 0.6f
            smZ += (depth - smZ) * 0.25f
        }

        val w = toWorld(smX, smY, smZ)
        if (s.n > 0) {
            val dx = w[0] - s.data[(s.n - 1) * 3]
            val dy = w[1] - s.data[(s.n - 1) * 3 + 1]
            val dz = w[2] - s.data[(s.n - 1) * 3 + 2]
            if (dx * dx + dy * dy + dz * dz < MIN_DIST2) {
                invalidate()
                return
            }
        }
        if (totalPoints < MAX_POINTS) {
            s.add(w[0], w[1], w[2])
            totalPoints++
        }
        invalidate()
    }

    // ---------- entrada por toque (girar a cena) ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tx = e.x
                ty = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                yaw -= (e.x - tx) * 0.006f
                pitch = (pitch + (e.y - ty) * 0.006f).coerceIn(-1.4f, 1.4f)
                tx = e.x
                ty = e.y
                invalidate()
            }
        }
        return true
    }

    // ---------- matemática 3D ----------
    // espaço da câmera -> espaço do mundo (desfaz a rotação orbital em torno do pivô)
    private fun toWorld(x: Float, y: Float, z: Float): FloatArray {
        val pz = z - PIVOT_Z
        val cX = cos(pitch)
        val sX = sin(pitch)
        val cY = cos(yaw)
        val sY = sin(yaw)
        val y1 = y * cX + pz * sX
        val z1 = -y * sX + pz * cX
        val x2 = x * cY - z1 * sY
        val z2 = x * sY + z1 * cY
        return floatArrayOf(x2, y1, z2 + PIVOT_Z)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (darkBackground) canvas.drawColor(Color.BLACK)

        val vw = width.toFloat()
        val vh = height.toFloat()
        val cX = cos(pitch)
        val sX = sin(pitch)
        val cY = cos(yaw)
        val sY = sin(yaw)

        for (s in strokes) {
            var hasPrev = false
            var prevX = 0f
            var prevY = 0f
            var prevZ = 0f
            for (i in 0 until s.n) {
                val x = s.data[i * 3]
                val y = s.data[i * 3 + 1]
                val rz = s.data[i * 3 + 2] - PIVOT_Z

                val x1 = x * cY + rz * sY
                val z1 = -x * sY + rz * cY
                val y2 = y * cX - z1 * sX
                val z2 = y * sX + z1 * cX + PIVOT_Z

                if (z2 < 0.15f) {
                    hasPrev = false
                    continue
                }
                val px = x1 / z2 * vh + vw / 2f
                val py = y2 / z2 * vh + vh / 2f

                val shade = (1.6f - z2 * 0.6f).coerceIn(0.35f, 1f)
                if (hasPrev) {
                    val zAvg = (z2 + prevZ) / 2f
                    paint.color = s.color
                    paint.alpha = (255 * shade).toInt()
                    paint.strokeWidth = (s.width / zAvg).coerceIn(1.5f, 90f)
                    canvas.drawLine(prevX, prevY, px, py, paint)
                } else if (s.n == 1) {
                    dotPaint.color = s.color
                    dotPaint.alpha = (255 * shade).toInt()
                    canvas.drawCircle(px, py, (s.width / z2).coerceIn(1.5f, 90f) / 2f, dotPaint)
                }
                hasPrev = true
                prevX = px
                prevY = py
                prevZ = z2
            }
        }
    }

    companion object {
        private const val PIVOT_Z = 1f
        private const val REF_PALM = 0.25f
        private const val MIN_DIST2 = 0.003f * 0.003f
        private const val MAX_POINTS = 60000
    }
}
