package com.example.mpcamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Desenha o esqueleto das mãos, o ponto de pinça e as infos de FPS. */
class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    @Volatile private var hands: List<FloatArray> = emptyList()
    @Volatile private var pointers: Array<Pointer?> = arrayOfNulls(2)
    @Volatile private var info = ""

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 80, 255, 120)
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        strokeWidth = 6f
        style = Paint.Style.STROKE
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 0, 229, 255)
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 38f
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun update(h: List<FloatArray>, p: Array<Pointer?>, infoText: String) {
        hands = h
        pointers = p
        info = infoText
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawText(info, 24f, 64f, textPaint)

        for (pts in hands) {
            var i = 0
            while (i < CONNECTIONS.size) {
                val a = CONNECTIONS[i]
                val b = CONNECTIONS[i + 1]
                canvas.drawLine(pts[a * 2], pts[a * 2 + 1], pts[b * 2], pts[b * 2 + 1], linePaint)
                i += 2
            }
            for (j in 0 until 21) canvas.drawCircle(pts[j * 2], pts[j * 2 + 1], 5f, dotPaint)
        }

        for (p in pointers) {
            if (p == null) continue
            if (p.pinch) canvas.drawCircle(p.x, p.y, 22f, fillPaint)
            else canvas.drawCircle(p.x, p.y, 30f, ringPaint)
        }
    }

    companion object {
        private val CONNECTIONS = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4,
            0, 5, 5, 6, 6, 7, 7, 8,
            5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16,
            13, 17, 17, 18, 18, 19, 19, 20,
            0, 17
        )
    }
}
