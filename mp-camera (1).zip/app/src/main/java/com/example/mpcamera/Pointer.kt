package com.example.mpcamera

/**
 * Ponto de "pinça" de uma mão, em coordenadas da tela.
 * palm = tamanho da palma relativo à altura da imagem (maior = mão mais perto da câmera).
 */
class Pointer(val x: Float, val y: Float, val pinch: Boolean, val palm: Float)
