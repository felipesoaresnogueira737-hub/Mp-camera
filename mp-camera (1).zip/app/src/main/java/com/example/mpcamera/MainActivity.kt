package com.example.mpcamera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var paintView: PaintView
    private lateinit var tvContainer: View
    private lateinit var tvBar: View
    private lateinit var paintBar: View
    private lateinit var tvProgress: ProgressBar
    private lateinit var tvHint: TextView
    private lateinit var btnPlay: TextView
    private lateinit var btnMute: TextView
    private lateinit var tvController: TvController
    private lateinit var player: ExoPlayer
    private lateinit var cameraExecutor: ExecutorService

    private val ui = Handler(Looper.getMainLooper())

    private var handLandmarker: HandLandmarker? = null
    private var delegateName = "CPU"
    private var lensFacing = CameraSelector.LENS_FACING_BACK

    @Volatile private var uprightW = 1
    @Volatile private var uprightH = 1
    @Volatile private var mirrored = false

    private var lastResultTime = 0L
    private var fps = 0f

    private var mode = MODE_TV
    private var muted = false

    // estado dos ponteiros (uma posição por mão: 0 = esquerda, 1 = direita)
    private val pinchState = BooleanArray(2)
    private val had = BooleanArray(2)
    private val smx = FloatArray(2)
    private val smy = FloatArray(2)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Permissão de câmera necessária", Toast.LENGTH_LONG).show()
            }
        }

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadVideo(uri)
        }

    private val progressTick = object : Runnable {
        override fun run() {
            val d = player.duration
            if (d > 0) tvProgress.progress = (player.currentPosition * 1000L / d).toInt()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        paintView = findViewById(R.id.paintView)
        tvContainer = findViewById(R.id.tvContainer)
        tvBar = findViewById(R.id.tvBar)
        paintBar = findViewById(R.id.paintBar)
        tvProgress = findViewById(R.id.tvProgress)
        tvHint = findViewById(R.id.tvHint)
        btnPlay = findViewById(R.id.btnPlay)
        btnMute = findViewById(R.id.btnMute)
        cameraExecutor = Executors.newSingleThreadExecutor()

        setupPlayer()
        setupTv()
        setupPaint()
        setupTopBar()
        setMode(MODE_TV)

        setupLandmarker()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    // ------------------------------------------------------------------ TV
    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build()
        player.repeatMode = Player.REPEAT_MODE_ALL
        findViewById<PlayerView>(R.id.playerView).player = player
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.text = if (isPlaying) "⏸" else "▶"
            }
        })
        ui.post(progressTick)
    }

    private fun setupTv() {
        val btnRew = findViewById<TextView>(R.id.btnRew)
        val btnFwd = findViewById<TextView>(R.id.btnFwd)

        btnPlay.setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.playWhenReady = !player.playWhenReady
        }
        btnRew.setOnClickListener {
            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
        }
        btnFwd.setOnClickListener {
            val d = player.duration
            var t = player.currentPosition + 10_000
            if (d > 0) t = t.coerceAtMost(d)
            player.seekTo(t)
        }
        btnMute.setOnClickListener {
            muted = !muted
            player.volume = if (muted) 0f else 1f
            btnMute.text = if (muted) "🔇" else "🔊"
        }

        tvController = TvController(
            container = tvContainer,
            progress = tvProgress,
            buttons = listOf(btnRew, btnPlay, btnFwd, btnMute)
        ) { fraction ->
            val d = player.duration
            if (d > 0) player.seekTo((d * fraction).toLong())
        }

        overlay.post { tvController.reset(overlay.width.toFloat(), overlay.height.toFloat()) }

        findViewById<Button>(R.id.btnImport).setOnClickListener {
            videoPicker.launch(arrayOf("video/*"))
        }
        findViewById<Button>(R.id.btnCenter).setOnClickListener {
            tvController.reset(overlay.width.toFloat(), overlay.height.toFloat())
        }
    }

    private fun loadVideo(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = true
        tvHint.visibility = View.GONE
    }

    // ------------------------------------------------------------------ Pintura
    private fun setupPaint() {
        val colors = intArrayOf(
            0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFFFFD60A.toInt(),
            0xFF30D158.toInt(), 0xFF64D2FF.toInt(), 0xFF0A84FF.toInt(),
            0xFFBF5AF2.toInt(), 0xFFFFFFFF.toInt()
        )
        val row = findViewById<LinearLayout>(R.id.colorRow)
        for (c in colors) {
            val t = TextView(this)
            t.text = "●"
            t.textSize = 28f
            t.setTextColor(c)
            t.setPadding(12, 0, 12, 0)
            t.setOnClickListener { paintView.color = c }
            row.addView(t)
        }

        findViewById<SeekBar>(R.id.brushSeek).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    paintView.brushWidth = 4f + p
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            }
        )

        findViewById<Button>(R.id.btnUndo).setOnClickListener { paintView.undo() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { paintView.clear() }
        findViewById<Button>(R.id.btnResetView).setOnClickListener { paintView.resetView() }
        findViewById<Button>(R.id.btnBg).setOnClickListener {
            paintView.darkBackground = !paintView.darkBackground
        }
        val btnRotate = findViewById<Button>(R.id.btnRotate)
        btnRotate.setOnClickListener {
            paintView.rotateMode = !paintView.rotateMode
            btnRotate.text = if (paintView.rotateMode) "Girar: ON" else "Girar: OFF"
        }
    }

    // ------------------------------------------------------------------ Modos / barra de cima
    private fun setupTopBar() {
        findViewById<Button>(R.id.btnModeTv).setOnClickListener { setMode(MODE_TV) }
        findViewById<Button>(R.id.btnModePaint).setOnClickListener { setMode(MODE_PAINT) }
        findViewById<Button>(R.id.btnSwitch).setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            overlay.update(emptyList(), arrayOfNulls(2), "")
            startCamera()
        }
    }

    private fun setMode(m: Int) {
        mode = m
        val tv = m == MODE_TV
        tvContainer.visibility = if (tv) View.VISIBLE else View.GONE
        tvBar.visibility = if (tv) View.VISIBLE else View.GONE
        paintView.visibility = if (tv) View.GONE else View.VISIBLE
        paintBar.visibility = if (tv) View.GONE else View.VISIBLE
    }

    // ------------------------------------------------------------------ MediaPipe
    private fun buildLandmarker(delegate: Delegate): HandLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .setDelegate(delegate)
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.3f)
            .setMinTrackingConfidence(0.3f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ ->
                val now = SystemClock.uptimeMillis()
                if (lastResultTime != 0L) {
                    val inst = 1000f / (now - lastResultTime).coerceAtLeast(1)
                    fps = if (fps == 0f) inst else fps * 0.9f + inst * 0.1f
                }
                lastResultTime = now
                val latency = now - result.timestampMs()
                val info = "$delegateName | $latency ms | ${"%.0f".format(fps)} FPS"

                val n = minOf(result.landmarks().size, 2)
                val raw = Array(n) { FloatArray(63) }
                val slots = IntArray(n)
                for (k in 0 until n) {
                    val lm = result.landmarks()[k]
                    for (j in 0 until 21) {
                        raw[k][j * 3] = lm[j].x()
                        raw[k][j * 3 + 1] = lm[j].y()
                        raw[k][j * 3 + 2] = lm[j].z()
                    }
                    val label = result.handedness().getOrNull(k)
                        ?.firstOrNull()?.categoryName() ?: "Right"
                    slots[k] = if (label == "Left") 0 else 1
                }
                if (n == 2 && slots[0] == slots[1]) slots[1] = 1 - slots[0]

                val w = uprightW
                val h = uprightH
                val mir = mirrored
                runOnUiThread { onHands(raw, slots, w, h, mir, info) }
            }
            .setErrorListener { e -> Log.e(TAG, "MediaPipe erro: ${e.message}") }
            .build()

        return HandLandmarker.createFromOptions(this, options)
    }

    private fun setupLandmarker() {
        try {
            handLandmarker = try {
                delegateName = "GPU"
                buildLandmarker(Delegate.GPU)
            } catch (e: Exception) {
                Log.w(TAG, "GPU indisponível, usando CPU", e)
                delegateName = "CPU"
                buildLandmarker(Delegate.CPU)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao carregar modelo", e)
            Toast.makeText(this, "Modelo hand_landmarker.task não encontrado em assets", Toast.LENGTH_LONG).show()
        }
    }

    /** Roda na thread de UI: converte landmarks em pontos de tela, detecta pinça e repassa pro modo atual. */
    private fun onHands(
        raw: Array<FloatArray>, slots: IntArray,
        w: Int, h: Int, mir: Boolean, info: String
    ) {
        val vw = overlay.width.toFloat()
        val vh = overlay.height.toFloat()
        if (vw == 0f || vh == 0f) return

        val scale = max(vw / w, vh / h)
        val ox = (vw - w * scale) / 2f
        val oy = (vh - h * scale) / 2f

        val skeletons = ArrayList<FloatArray>()
        val pointers = arrayOfNulls<Pointer>(2)
        val present = BooleanArray(2)

        for (k in raw.indices) {
            val r = raw[k]
            val pts = FloatArray(42)
            for (j in 0 until 21) {
                val nx = if (mir) 1f - r[j * 3] else r[j * 3]
                pts[j * 2] = nx * w * scale + ox
                pts[j * 2 + 1] = r[j * 3 + 1] * h * scale + oy
            }
            skeletons.add(pts)

            // tamanho da palma (pulso -> base do dedo médio) e distância da pinça, relativos à altura da imagem
            val palm = hypot((r[27] - r[0]) * w, (r[28] - r[1]) * h) / h
            val pinchD = hypot((r[12] - r[24]) * w, (r[13] - r[25]) * h) / h
            val ratio = pinchD / max(palm, 0.001f)

            // ponto de pinça = meio entre a ponta do polegar (4) e do indicador (8)
            val mx = (pts[8] + pts[16]) / 2f
            val my = (pts[9] + pts[17]) / 2f

            val s = slots[k]
            if (!had[s]) {
                smx[s] = mx
                smy[s] = my
            } else {
                smx[s] += (mx - smx[s]) * 0.65f
                smy[s] += (my - smy[s]) * 0.65f
            }
            had[s] = true
            present[s] = true

            if (pinchState[s]) {
                if (ratio > 0.42f) pinchState[s] = false
            } else if (ratio < 0.28f) pinchState[s] = true

            pointers[s] = Pointer(smx[s], smy[s], pinchState[s], palm)
        }
        for (s in 0..1) if (!present[s]) {
            had[s] = false
            pinchState[s] = false
        }

        overlay.update(skeletons, pointers, info)
        if (mode == MODE_TV) tvController.process(pointers, vw, vh)
        else paintView.update(pointers)
    }

    // ------------------------------------------------------------------ Câmera
    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val resolution = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(640, 480),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolution)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
                .also { it.setAnalyzer(cameraExecutor, ::analyze) }

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Falha ao iniciar câmera", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val landmarker = handLandmarker
        if (landmarker == null) {
            proxy.close()
            return
        }

        val rotation = proxy.imageInfo.rotationDegrees
        val bitmap = Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888)
        proxy.use { bitmap.copyPixelsFromBuffer(it.planes[0].buffer) }

        val swap = rotation == 90 || rotation == 270
        uprightW = if (swap) bitmap.height else bitmap.width
        uprightH = if (swap) bitmap.width else bitmap.height
        mirrored = lensFacing == CameraSelector.LENS_FACING_FRONT

        val processing = ImageProcessingOptions.builder()
            .setRotationDegrees(rotation)
            .build()

        landmarker.detectAsync(
            BitmapImageBuilder(bitmap).build(),
            processing,
            SystemClock.uptimeMillis()
        )
    }

    override fun onPause() {
        super.onPause()
        player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(progressTick)
        player.release()
        cameraExecutor.shutdown()
        handLandmarker?.close()
    }

    companion object {
        private const val TAG = "MPCamera"
        private const val MODE_TV = 0
        private const val MODE_PAINT = 1
    }
}
