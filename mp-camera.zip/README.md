# MP Camera

App Android mínimo: câmera (CameraX) + MediaPipe Hand Landmarker, desenhando os pontos da mão em tempo real.

## Gerar o APK pelo GitHub
1. Crie um repositório e suba todos estes arquivos (branch `main`).
2. Vá em **Actions → Build APK** (roda sozinho a cada push, ou clique em *Run workflow*).
3. Ao terminar, baixe o artefato **app-debug-apk** (zip com o `.apk`).
4. Instale no celular (permita "fontes desconhecidas").

O workflow baixa o modelo `hand_landmarker.task` automaticamente.

## Compilar localmente
Baixe o modelo para `app/src/main/assets/hand_landmarker.task`:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
e rode `gradle assembleDebug` (Gradle 8.7, JDK 17).
