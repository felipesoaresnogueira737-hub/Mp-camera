package com.example.mpcamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.max

/** Desenha os landmarks da mão por cima do preview (escala FILL_CENTER). */
class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private var result: HandLandmarkerResult? = null
    private var imageWidth = 1
    private var imageHeight = 1

    private val linePaint = Paint().apply {
        color = Color.GREEN
        strokeWidth = 6f
        style = Paint.Style.STROKE
    }
    private val pointPaint = Paint().apply {
        color = Color.YELLOW
        strokeWidth = 12f
        style = Paint.Style.FILL
    }

    fun setResults(r: HandLandmarkerResult?, imgWidth: Int, imgHeight: Int) {
        result = r
        imageWidth = imgWidth
        imageHeight = imgHeight
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val res = result ?: return

        val scale = max(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        val offsetX = (width - imageWidth * scale) / 2f
        val offsetY = (height - imageHeight * scale) / 2f

        fun px(x: Float) = x * imageWidth * scale + offsetX
        fun py(y: Float) = y * imageHeight * scale + offsetY

        for (hand in res.landmarks()) {
            for (c in HandLandmarker.HAND_CONNECTIONS) {
                val a = hand[c.start()]
                val b = hand[c.end()]
                canvas.drawLine(px(a.x()), py(a.y()), px(b.x()), py(b.y()), linePaint)
            }
            for (p in hand) {
                canvas.drawPoint(px(p.x()), py(p.y()), pointPaint)
            }
        }
    }
}
